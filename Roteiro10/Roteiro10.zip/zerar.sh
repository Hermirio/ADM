#!/bin/bash

for ((i=$1; i>=$2; i--))
do
	echo -n "$i "
done
echo " "
